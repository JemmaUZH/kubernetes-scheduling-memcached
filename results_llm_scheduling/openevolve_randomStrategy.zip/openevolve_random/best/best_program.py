import subprocess
import time

# ============================================================
# Initial scheduling program for OpenEvolve (medium baseline)
# Some jobs on node-a, some on node-b, but not optimal
# LLM should improve thread counts, core assignment, and order
# ============================================================

def create_job(name, image, node_label, cores, threads, run_cmd_str):
    yaml = f"""
apiVersion: batch/v1
kind: Job
metadata:
  name: {name}
spec:
  template:
    spec:
      containers:
      - image: {image}
        name: {name}
        imagePullPolicy: Always
        command: ["/bin/sh"]
        args: ["-c", "taskset -c {cores} {run_cmd_str} -n {threads}"]
      restartPolicy: Never
      nodeSelector:
        cca-project-nodetype: "{node_label}"
"""
    proc = subprocess.run(
        ["kubectl", "create", "-f", "-"],
        input=yaml, capture_output=True, text=True
    )
    print(f"Created {name}: {proc.stdout.strip()} {proc.stderr.strip()}")

def wait_for_job(name, timeout=900):
    print(f"Waiting for {name}...")
    result = subprocess.run(
        ["kubectl", "wait", "--for=condition=complete",
         f"job/{name}", f"--timeout={timeout}s"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"{name} completed!")
        return True
    else:
        print(f"{name} failed: {result.stderr}")
        return False

def delete_all_jobs():
    subprocess.run("kubectl delete jobs --all --ignore-not-found=true",
                   shell=True, capture_output=True)
    subprocess.run("kubectl delete pods --all --ignore-not-found=true",
                   shell=True, capture_output=True)
    time.sleep(5)

# ============================================================
# EVOLVE-BLOCK-START
# Medium baseline: half jobs on node-a, half on node-b
# 2 threads each, all launched simultaneously
# Not optimal - LLM should improve:
# - Better thread counts (up to 4 on node-b, up to 6 on node-a)
# - Better job placement based on interference sensitivity
# - Better launch order to minimize makespan
# ============================================================

def schedule():
    """
    Optimized scheduling policy for minimal makespan with SLO protection.
    
    Strategy:
    - node-b (4 cores, no interference): ALL high-interference jobs
    - node-a (6 cores, memcached present): ONLY low-interference jobs
    
    Interference sensitivity (LLC column):
    - barnes=2.6x, vips=2.3x, freqmine=2.3x → HIGH (node-b only)
    - canneal=2.1x, streamcluster=1.8x → MODERATE-HIGH (node-b)
    - blackscholes=1.7x, radix=1.7x → LOW (safe on node-a)
    
    Thread optimization:
    - node-b: 4 threads per job (full utilization)
    - node-a: 2 threads per job (conservative, safe for memcached)
    """

    # Phase 1: node-b - Run 2 jobs in parallel with 4 threads each
    # streamcluster (4t=107s) + canneal (4t=93s) → 107s parallel
    create_job("parsec-streamcluster", "anakli/cca:parsec_streamcluster",
               "node-b", "0-3", 4,
               "./run -a run -S parsec -p streamcluster -i native")

    create_job("parsec-canneal", "anakli/cca:parsec_canneal",
               "node-b", "0-3", 4,
               "./run -a run -S parsec -p canneal -i native")

    # Phase 1: node-a - Run 2 safe jobs in parallel with optimized thread counts
    # blackscholes (4t=25s) + radix (2t=17s) → 25s parallel
    # Using cores 2-5 for blackscholes (4 threads), cores 6-7 for radix (2 threads)
    create_job("parsec-blackscholes", "anakli/cca:parsec_blackscholes",
               "node-a", "2-5", 4,
               "./run -a run -S parsec -p blackscholes -i native")

    create_job("parsec-radix", "anakli/cca:splash2x_radix",
               "node-a", "6-7", 2,
               "./run -a run -S splash2x -p radix -i native")

    # Wait for phase 1 to complete
    wait_for_job("parsec-streamcluster")
    wait_for_job("parsec-canneal")
    wait_for_job("parsec-blackscholes")
    wait_for_job("parsec-radix")

    # Phase 2: node-b - Run freqmine alone (longest remaining job)
    # freqmine (4t=85s) → 85s
    # barnes moved to Phase 3 to run in parallel with vips on node-a
    create_job("parsec-freqmine", "anakli/cca:parsec_freqmine",
               "node-b", "0-3", 4,
               "./run -a run -S parsec -p freqmine -i native")

    # Wait for phase 2
    wait_for_job("parsec-freqmine")

    # Phase 3: Run vips on node-a (short job, frees node-b capacity)
    # vips (2t=31s) on node-a cores 2-3, barnes (4t=29s) on node-b
    # Parallel execution across both nodes
    create_job("parsec-vips", "anakli/cca:parsec_vips",
               "node-a", "2-3", 2,
               "./run -a run -S parsec -p vips -i native")

    create_job("parsec-barnes", "anakli/cca:splash2x_barnes",
               "node-b", "0-3", 4,
               "./run -a run -S splash2x -p barnes -i native")

    wait_for_job("parsec-vips")
    wait_for_job("parsec-barnes")

# EVOLVE-BLOCK-END
# ============================================================

if __name__ == "__main__":
    print("=== Starting scheduling ===")
    start = time.time()

    subprocess.run("kubectl label nodes node-a-8core-tjn4 cca-project-nodetype=node-a --overwrite",
                   shell=True, capture_output=True)
    subprocess.run("kubectl label nodes node-b-4core-rj6b cca-project-nodetype=node-b --overwrite",
                   shell=True, capture_output=True)

    delete_all_jobs()
    schedule()

    makespan = time.time() - start
    print(f"=== Total makespan: {makespan:.1f}s ===")
    subprocess.run("kubectl get pods -o json > pods_openevolve.json", shell=True)
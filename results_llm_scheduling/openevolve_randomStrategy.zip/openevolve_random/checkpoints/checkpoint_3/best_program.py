import subprocess
import time

# ============================================================
# Initial scheduling program for OpenEvolve (medium baseline)
# Some jobs on node-a, some on node-b, but not optimal
# LLM should improve thread counts, core assignment, and order
# ============================================================

def create_job(name, image, node_label, cores, threads, run_cmd_str):
    yaml = f"""
apiVersion: batch/v1
kind: Job
metadata:
  name: {name}
spec:
  template:
    spec:
      containers:
      - image: {image}
        name: {name}
        imagePullPolicy: Always
        command: ["/bin/sh"]
        args: ["-c", "taskset -c {cores} {run_cmd_str} -n {threads}"]
      restartPolicy: Never
      nodeSelector:
        cca-project-nodetype: "{node_label}"
"""
    proc = subprocess.run(
        ["kubectl", "create", "-f", "-"],
        input=yaml, capture_output=True, text=True
    )
    print(f"Created {name}: {proc.stdout.strip()} {proc.stderr.strip()}")

def wait_for_job(name, timeout=900):
    print(f"Waiting for {name}...")
    result = subprocess.run(
        ["kubectl", "wait", "--for=condition=complete",
         f"job/{name}", f"--timeout={timeout}s"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"{name} completed!")
        return True
    else:
        print(f"{name} failed: {result.stderr}")
        return False

def delete_all_jobs():
    subprocess.run("kubectl delete jobs --all --ignore-not-found=true",
                   shell=True, capture_output=True)
    subprocess.run("kubectl delete pods --all --ignore-not-found=true",
                   shell=True, capture_output=True)
    time.sleep(5)

# ============================================================
# EVOLVE-BLOCK-START
# Medium baseline: half jobs on node-a, half on node-b
# 2 threads each, all launched simultaneously
# Not optimal - LLM should improve:
# - Better thread counts (up to 4 on node-b, up to 6 on node-a)
# - Better job placement based on interference sensitivity
# - Better launch order to minimize makespan
# ============================================================

def schedule():
    """
    Medium baseline scheduling policy.
    
    Cluster:
    - node-a: 8 cores (0-1 = memcached, 2-7 = batch jobs available)
    - node-b: 4 cores (0-3 = batch jobs available)
    
    Job runtimes with 2 threads (seconds):
    streamcluster=234, canneal=141, freqmine=172,
    barnes=55, blackscholes=38, vips=31, radix=17
    
    Interference sensitivity (high = avoid node-a):
    - streamcluster: CPU sensitive → node-b
    - canneal: LLC sensitive → node-b
    - freqmine: CPU sensitive → node-b
    - barnes: moderate → node-a
    - blackscholes: low → node-a
    - vips: moderate → node-a
    - radix: low → node-a
    """

    # node-b: CPU/LLC sensitive jobs (2 threads each)
    create_job("parsec-streamcluster", "anakli/cca:parsec_streamcluster",
               "node-b", "0-1", 2,
               "./run -a run -S parsec -p streamcluster -i native")

    create_job("parsec-canneal", "anakli/cca:parsec_canneal",
               "node-b", "2-3", 2,
               "./run -a run -S parsec -p canneal -i native")

    # node-a: lower interference jobs (2 threads each)
    create_job("parsec-blackscholes", "anakli/cca:parsec_blackscholes",
               "node-a", "2-3", 2,
               "./run -a run -S parsec -p blackscholes -i native")

    create_job("parsec-radix", "anakli/cca:splash2x_radix",
               "node-a", "4-5", 2,
               "./run -a run -S splash2x -p radix -i native")

    create_job("parsec-vips", "anakli/cca:parsec_vips",
               "node-a", "6-7", 2,
               "./run -a run -S parsec -p vips -i native")

    # Wait for fast jobs first
    wait_for_job("parsec-blackscholes")
    wait_for_job("parsec-radix")
    wait_for_job("parsec-vips")

    # node-a cores now free, start remaining jobs
    create_job("parsec-freqmine", "anakli/cca:parsec_freqmine",
               "node-a", "2-3", 2,
               "./run -a run -S parsec -p freqmine -i native")

    create_job("parsec-barnes", "anakli/cca:splash2x_barnes",
               "node-a", "4-5", 2,
               "./run -a run -S splash2x -p barnes -i native")

    # Wait for all remaining
    wait_for_job("parsec-streamcluster")
    wait_for_job("parsec-canneal")
    wait_for_job("parsec-freqmine")
    wait_for_job("parsec-barnes")

# EVOLVE-BLOCK-END
# ============================================================

if __name__ == "__main__":
    print("=== Starting scheduling ===")
    start = time.time()

    subprocess.run("kubectl label nodes node-a-8core-tjn4 cca-project-nodetype=node-a --overwrite",
                   shell=True, capture_output=True)
    subprocess.run("kubectl label nodes node-b-4core-rj6b cca-project-nodetype=node-b --overwrite",
                   shell=True, capture_output=True)

    delete_all_jobs()
    schedule()

    makespan = time.time() - start
    print(f"=== Total makespan: {makespan:.1f}s ===")
    subprocess.run("kubectl get pods -o json > pods_openevolve.json", shell=True)